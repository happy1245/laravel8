<html>

<body>
   <h1>cat of jirapat 60xxxxxxxx</h1>
   <h1><img src=<?php echo e($cat); ?>></h1>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel8\resources\views/test/cat.blade.php ENDPATH**/ ?>