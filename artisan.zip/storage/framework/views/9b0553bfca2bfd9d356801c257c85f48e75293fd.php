<table class="table table-striped">
    <thead>
        <tr>
            <th>#</th>
            <th>รหัสนักศึกษา</th>
            <th>ชื่อสกุล</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $students = json_decode(file_get_contents('https://raw.githubusercontent.com/arc6828/laravel8/main/public/json/students.json'));
        ?>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($row->id); ?></td>
            <td><?php echo e($row->name); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\laravel8\resources\views/student.blade.php ENDPATH**/ ?>