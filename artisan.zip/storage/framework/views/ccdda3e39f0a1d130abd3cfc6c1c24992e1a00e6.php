<html>
    <body>
        <h1>Hello, <?php echo e($name); ?> </h1>
        <h1>Hello, <?php echo $name; ?> </h1>
        <h1>Hello, <?php echo e($name); ?> <?php echo e($last_name); ?> </h1>
        <h1>Hello, <?php echo e($name . " " . $last_name); ?> </h1>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel8\resources\views/greeting.blade.php ENDPATH**/ ?>