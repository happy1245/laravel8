<html>

<body>
    <p1>ant</p1><a href="gallery/ant"><img src=<?php echo e($ant); ?> width="300"></a>
    <p1>bird</p1><a href="gallery/bird"><img src=<?php echo e($bird); ?> width="300"></a>
    <p1>cat</p1><a href="gallery/cat"><img src=<?php echo e($cat); ?> width="300"></a>
    <p1>god</p1></h1><img src=<?php echo e($god); ?> width="300">
    <p1>spider</p1></h1><img src=<?php echo e($spider); ?> width="300">
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel8\resources\views/test/index.blade.php ENDPATH**/ ?>