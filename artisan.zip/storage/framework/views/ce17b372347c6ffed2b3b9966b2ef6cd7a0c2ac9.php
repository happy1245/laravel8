<table class="table table-striped">
    <thead>
        <tr>
            <th>#</th>
            <th>ชื่อสกุล</th>
            <th>อีเมล์</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $teachers = json_decode(file_get_contents('https://raw.githubusercontent.com/arc6828/laravel8/main/public/json/teachers.json'));
        ?>
        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><img class="rounded" src="<?php echo e($row->image); ?>" height="30" /></td>
            <td><?php echo e($row->role); ?> <?php echo e($row->name); ?></td>
            <td><?php echo e($row->email); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\laravel8\resources\views/teacher.blade.php ENDPATH**/ ?>