<html>

<body>
   <h1>bird of jirapat 60xxxxxxxx</h1>
   <h1><img src=<?php echo e($bird); ?>></h1>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel8\resources\views/test/bird.blade.php ENDPATH**/ ?>