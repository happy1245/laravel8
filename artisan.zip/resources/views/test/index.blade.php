<html>

<body>
    <p1>ant</p1><a href="gallery/ant"><img src={{$ant}} width="300"></a>
    <p1>bird</p1><a href="gallery/bird"><img src={{$bird}} width="300"></a>
    <p1>cat</p1><a href="gallery/cat"><img src={{$cat}} width="300"></a>
    <p1>god</p1></h1><img src={{$god}} width="300">
    <p1>spider</p1></h1><img src={{$spider}} width="300">
</body>

</html>